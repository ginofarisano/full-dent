package guiSegretaria;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.GroupLayout;

import gestioneCalendario.DBCalendario;
import gestioneCalendario.Data;
import gestioneCalendario.DatiAppuntamento;
import guiAccessi.FormAccessi;
import guiCalendario.FormAggiungiAppuntamento;
import guiCalendario.FormVisualizzaAppuntamenti;
import guiCalendario.FormVisualizzaRichiami;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.LayoutStyle;
import javax.swing.border.LineBorder;

/**
 * Classe che specifica un calendario generico e un calendario con gli appuntamenti quotidiani.
 * @author G.Valitutto
 */
public class FormCalendario extends javax.swing.JFrame {

    /** 
     * Crea un nuovo Form.
     */
    public FormCalendario() {
        initComponents();
    }

    /**
     * Metodo di supporto che inizializza le componenti del Frame.
     */
    private void initComponents() {

        desertRed1 = new com.jgoodies.looks.plastic.theme.DesertRed();
        desertRed2 = new com.jgoodies.looks.plastic.theme.DesertRed();
        jCalendar1 = new com.toedter.calendar.JCalendar();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        GroupLayout layout = new GroupLayout((JComponent)getContentPane());
        getContentPane().setLayout(layout);
        jComboBox1 = new javax.swing.JComboBox();
        jButton2 = new javax.swing.JButton();
        label1 = new java.awt.Label();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jCalendar1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jCalendar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCalendar1MouseClicked(evt);
            }
        });
        jCalendar1.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                jCalendar1ComponentHidden(evt);
            }
        });
        jCalendar1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jCalendar1PropertyChange(evt);
            }
        });
        jCalendar1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jCalendar1AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 12));         
        jLabel1.setForeground(new java.awt.Color(0, 51, 255));
        jLabel1.setText("Per visualizzare gli appuntamenti giornalieri");

        jLabel2.setText("Selezionare una data:");

        jButton1.setText("Ok");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel3.setText("Servizio:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addContainerGap(52, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(157, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(90, 90, 90))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jLabel4.setText("Moduli:");
        {
        	jPanel2 = new JPanel();
        	jPanel2.setBorder(new LineBorder(new java.awt.Color(0,0,0), 1, false));
        	jPanel2.setLayout(null);
        	{
        		jButton3 = new javax.swing.JButton();
        		jPanel2.add(jButton3);
        		jButton3.setText("Richiami");
        		jButton3.setBounds(56, 22, 92, 22);
        		jButton3.addActionListener(new java.awt.event.ActionListener() {
        			public void actionPerformed(java.awt.event.ActionEvent evt) {
        				jButton3ActionPerformed(evt);
        			}
        		});
        	}
        	{
        		nuovo = new JButton();
        		jPanel2.add(nuovo);
        		nuovo.setText("Nuovo");
        		nuovo.setBounds(203, 22, 80, 22);
        		nuovo.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        jButtonNuovoActionPerformed(evt);
                    }
                });
        	}
        }
        {
        	appunt = new JLabel();
        	appunt.setText("Appuntamenti:");
        	appunt.setBounds(26, 9, 80, 16);
        	appunt.setForeground(new java.awt.Color(0,51,255));
        	
        }
        
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Standard1", "Standard2", "Standard3" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jButton2.setText("Stampa");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        label1.setFont(new java.awt.Font("Dialog", 0, 24));
        label1.setForeground(new java.awt.Color(0, 51, 255));
        label1.setText("Calendario");

        jButton4.setText("Logout");
        layout.setVerticalGroup(layout.createSequentialGroup()
        	.addContainerGap()
        	.addGroup(layout.createParallelGroup()
        	    .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
        	        .addComponent(jButton4, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
        	        .addGap(10))
        	    .addComponent(label1, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE))
        	.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
        	.addGroup(layout.createParallelGroup()
        	    .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
        	        .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, 220, GroupLayout.PREFERRED_SIZE)
        	        .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED, 1, Short.MAX_VALUE)
        	        .addComponent(appunt, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
        	        .addGap(6))
        	    .addComponent(jCalendar1, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 255, GroupLayout.PREFERRED_SIZE))
        	.addGroup(layout.createParallelGroup()
        	    .addComponent(jPanel2, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 63, GroupLayout.PREFERRED_SIZE)
        	    .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
        	        .addGap(12)
        	        .addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
        	        .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
        	        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
        	            .addComponent(jComboBox1, GroupLayout.Alignment.BASELINE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
        	            .addComponent(jButton2, GroupLayout.Alignment.BASELINE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE))))
        	.addContainerGap(21, 21));
        layout.setHorizontalGroup(layout.createSequentialGroup()
        	.addContainerGap()
        	.addGroup(layout.createParallelGroup()
        	    .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
        	        .addGroup(layout.createParallelGroup()
        	            .addComponent(jComboBox1, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 92, GroupLayout.PREFERRED_SIZE)
        	            .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
        	                .addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
        	                .addGap(51)))
        	        .addGap(18)
        	        .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
        	        .addGap(192))
        	    .addComponent(jCalendar1, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 356, GroupLayout.PREFERRED_SIZE)
        	    .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
        	        .addComponent(label1, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
        	        .addGap(240)))
        	.addGap(18)
        	.addGroup(layout.createParallelGroup()
        	    .addComponent(jPanel1, GroupLayout.Alignment.LEADING, 0, 321, Short.MAX_VALUE)
        	    .addComponent(jPanel2, GroupLayout.Alignment.LEADING, 0, 321, Short.MAX_VALUE)
        	    .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
        	        .addComponent(appunt, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
        	        .addGap(163)
        	        .addComponent(jButton4, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)
        	        .addGap(0, 26, Short.MAX_VALUE)))
        	.addContainerGap());
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        this.setTitle("FullDent - Calendario");

        pack();
    }

    private void jCalendar1MouseClicked(java.awt.event.MouseEvent evt) {                                        

    }                                       

    private void jCalendar1AncestorAdded(javax.swing.event.AncestorEvent evt) {                                         
        
    }                                        

    private void jCalendar1PropertyChange(java.beans.PropertyChangeEvent evt) {                                          
    
    }                                         

    private void jCalendar1ComponentHidden(java.awt.event.ComponentEvent evt) {                                           

    }                                          

    /**
     * Azione eseguita alla pressione del tasto "ok".
     * @param evt il ricevitore d'evento.
     */
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
    	try{
    		String scelta = jTextField1.getText();
    		String data = "";
    		if((jDateChooser1.getDate().getMonth()+1)<10){
    			if(jDateChooser1.getDate().getDate()<10)
    				data = "0"+(jDateChooser1.getDate().getDate())+"/0"+(jDateChooser1.getDate().getMonth()+1)
					+"/"+(jDateChooser1.getDate().getYear()+1900);
    			else data = ""+(jDateChooser1.getDate().getDate())+"/0"+(jDateChooser1.getDate().getMonth()+1)
    					+"/"+(jDateChooser1.getDate().getYear()+1900);
    		}else{ 
    			if(jDateChooser1.getDate().getDate()<10){
    				data = "0"+(jDateChooser1.getDate().getDate())+"/"+(jDateChooser1.getDate().getMonth()+1)
								+"/"+(jDateChooser1.getDate().getYear()+1900);
    			}else data = ""+(jDateChooser1.getDate().getDate())+"/"+(jDateChooser1.getDate().getMonth()+1)
					+"/"+(jDateChooser1.getDate().getYear()+1900);
    		}
    		Data nuova = new Data(data,"");
    		if(!scelta.equals("")){
    			DBCalendario x = new DBCalendario();
    			x.openConnection();
    			ArrayList<DatiAppuntamento> elenco = x.visualizza(scelta,nuova);
    			x.closeConnection();
    			FormVisualizzaAppuntamenti z = new FormVisualizzaAppuntamenti(elenco);
    			z.setVisible(true);
    			this.setVisible(false);
    		}else errore("Il campo Servizio deve essere inserito!");
    	}catch(NullPointerException e){
    		errore("Data non inserita!");
    	}catch(SQLException e){
			errore("Errore d'accesso al DataBase!");
		}catch(FileNotFoundException e){
			errore("File di accesso al DataBase non trovato!");
		} catch (ClassNotFoundException e) {
			errore("Classe non trovata!");
		} catch (IOException e) {
			errore("Errore di comunicazione con il file!");
		}
    	
    }                                                                             

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {                                           
    	
    }                                          

    /**
     * Azione eseguita alla pressione del bottone "stampa".
     * @param evt il ricevitore d'evento.
     */
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
    	String scelta = (String)jComboBox1.getSelectedItem();
    	if(scelta.equals("Standard1")){
    		    	
    	}
    	if(scelta.equals("Standard2")){
    		
    	}
    	if(scelta.equals("Standard3")){
    			
    	}
    }                                        
 
    /**
     * Azione eseguita alla pressione del bottone "richiami".
     * @param evt il ricevitore d'evento.
     */
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {                                         
       	FormVisualizzaRichiami x = new FormVisualizzaRichiami();
    	x.setVisible(true);
    	this.setVisible(false);
    }                                        

    /**
     * Azione eseguita alla pressione del bottone "logout".
     * @param evt il ricevitore d'evento.
     */
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
    	this.setVisible(false);
    	new FormAccessi().setVisible(true);
    }                                                                             

    /**
     * Azione eseguita alla pressione del bottone "nuovo".
     * Aggiunge un nuovo appuntamento.
     * @param evt il ricevitore d'evento.
     */
    private void jButtonNuovoActionPerformed(java.awt.event.ActionEvent evt) {                                         
    	FormAggiungiAppuntamento x = new FormAggiungiAppuntamento();
    	x.setVisible(true);
    	this.setVisible(false);
    }
    
    /**
     * Frame contenente un messaggio di errore scelto.
     * @param mex il messaggio di errore.
     */
    protected void errore(String mex){
    	JOptionPane.showMessageDialog(null,mex);
	}
    
    /**
     * Frame contenente un messaggio di conferma dell'operazione.
     */
    protected void successo(){
    	JOptionPane.showMessageDialog(null,"Operazione effettuata!");
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormCalendario().setVisible(true);
            }
        });
    }

    private com.jgoodies.looks.plastic.theme.DesertRed desertRed1;
    private com.jgoodies.looks.plastic.theme.DesertRed desertRed2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JComboBox jComboBox1;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private java.awt.Label label1;
    private JLabel appunt;
    private JPanel jPanel2;
    private JButton nuovo;

}
