package junit_test;

import junit.framework.TestCase;
import gestioneAttrezzature.DatiAttrezzature;

public class DatiAttrezzature_test extends TestCase{

	private DatiAttrezzature attrezzatura;
	
	public DatiAttrezzature_test(String s){
		super(s);
	}
	
	public void setUp(){
		try {
			attrezzatura = new DatiAttrezzature(1,"spazzolino",10,1.5,"materiale","lava i denti","bagno","asdfghjklzxcvbnm");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void testGetCodiceTipo(){
		assertEquals(1, attrezzatura.getCodiceTipo());
	}
	
	public void testGetNome(){
		assertEquals("spazzolino", attrezzatura.getNome());
	}
	
	public void testGetQuantit�(){
		assertEquals(10, attrezzatura.getQuantit�());
	}
	
	public void testGetCosto(){
		assertEquals(1.5, attrezzatura.getCosto());
	}
	
	public void testGetTipo(){
		assertEquals("materiale", attrezzatura.getTipo());
	}
	
	public void testGetDescizione(){
		assertEquals("lava i denti", attrezzatura.getDescrizione());
	}
	
	public void testGetLocazione(){
		assertEquals("bagno", attrezzatura.getLocazione());
	}
	
	public void testGetCodiceFornitore(){
		assertEquals("asdfghjklzxcvbnm", attrezzatura.getCodiceFornitore());
	}
		
	public void testSetQuantit�(){
		try{
			attrezzatura.setQuantit�(15);
		}catch(Exception e){
			e.printStackTrace();
			assertEquals(15, attrezzatura.getQuantit�());
		}
	}

	public void testSetDescrizione(){
		try{
			attrezzatura.setDescrizione("non lava pi�");
		}catch(Exception e){
			e.printStackTrace();
			assertEquals("non lava pi�", attrezzatura.getDescrizione());
		}
	}
	
	public void testSetLocazione(){
		try{
			attrezzatura.setLocazione("deposito");
		}catch(Exception e){
			e.printStackTrace();
			assertEquals("deposito", attrezzatura.getLocazione());
		}
	}

	public void tearDown(){
		attrezzatura = null;
	}
	
}
